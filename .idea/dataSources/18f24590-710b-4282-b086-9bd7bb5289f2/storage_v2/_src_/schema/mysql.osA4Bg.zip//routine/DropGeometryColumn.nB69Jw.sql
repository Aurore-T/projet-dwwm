create
    definer = `mariadb.sys`@localhost procedure DropGeometryColumn(IN catalog varchar(64), IN t_schema varchar(64),
                                                                   IN t_name varchar(64),
                                                                   IN geometry_column varchar(64)) sql security invoker
begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' DROP ', geometry_column); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end;

